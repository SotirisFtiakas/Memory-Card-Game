# MEMORY GAME #
Part 1:
a.Creation of Card
b.Creation of Table

Part 2:
a.Changes in Table
b.Creation of UI

Part 3:
a.Commentary of class Card
b.Commentary of class Table

Part 4:
a.Continuation of class UI
b.Small changes in Table

Part 5:
a.Continuation of class UI
b.Creation of Player

Part 6:
a.Minor appearance changes

Part 7:
a.Bug Fixing in UI class

Part 7.5 & 8:
a.Javadoc implementation

Part 9:
a. Minor Javadoc changes
b. Small Bug Fixing in UI class

Part 10:
a.First step in graphic design

Part 10.1:
TESTING BRANCH-COMMIT

Part 11:
a. Construction of classes: Computer, SinglePlayer, MultiPlayer
b. Logic implementation

Part 12
a. Update of class myGUI to GUI
b. Construction of classes: startMenu, playMenu, optionMenu, playDuelMenu, playerName

Part 13
a. Minor changes in classes optionMenu, playMenu
b. Creation of the new class GraphicTable for experimentation

Part 14
a. Construction of classes: highscoreMenu, GUICard, PlayerPanel
b. Minor changes in some classes

Part 15
a. Connection of PlayerPanel with playMenu
b. Code that will help later on

Part 16
a. Construction of classes: gamePanel,infoPanel
b. Changes in some classes

Part 17
a. Minor changes in some classes
b. Uploaded some cool images

Part 17.5
a. Changes in PlayerPanel and some other minor changes 
to some classes resulting to easier management

Part 18
a. Almost finished with the Basic, Double and Triple games
b. Debugging
c. Many checks and handling of user-misbehavior

Part 19
a. Construction of class highScoreTable
b. Minor changes in gamePanel

Part 20
a. Progress with Bots
b. Progress with Duel Mode

Part 21
a. Enable of Language Changing
b. Addition of player's name control methods

Part 22
a. Javadoc and small changes

Part 23
a. Complete bot actions
b. Full Javadoc
c. JUnit Testing

Part 24
FINAL COMMIT